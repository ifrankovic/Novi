#ifndef Direktor_h
#define Direktor_h

#include "Zaposlenik.h"


class Direktor : public Zaposlenik {};

#endif // Direktor_h
