#ifndef DirektorOdjela_h
#define DirektorOdjela_h

#include "Direktor.h"
#include "void.h"


class DirektorOdjela : public Direktor {

 public:

    virtual void zaposliDPO();

    virtual void otpustiDPO();

    virtual void zaposliRadnika();

    virtual void otpustiRadnika();
};

#endif // DirektorOdjela_h
