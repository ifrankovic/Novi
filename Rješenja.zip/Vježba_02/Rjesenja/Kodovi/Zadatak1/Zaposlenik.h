#ifndef Zaposlenik_h
#define Zaposlenik_h

#include <vector>

#include "string.h"

class Posao;

class Zaposlenik {

 public:
    string MBZaposlenika;
    string ime;
    string prezime;

 public:


    /**
     * @element-type Posao
     */
    std::vector< Posao* > myPosao;
};

#endif // Zaposlenik_h
