#ifndef Pododjel_h
#define Pododjel_h

#include "DirektorPododjela.h"
#include "Radnik.h"
#include "Zaposlenik.h"
#include "string.h"


class Pododjel {

 public:
    string nazivOdjela;
    string adresaOdjela;
    string nazivPododjela;

 public:


    /**
     * @element-type Zaposlenik
     */
    Zaposlenik myZaposlenik;

    /**
     * @element-type Radnik
     */
    Radnik myRadnik;

    /**
     * @element-type DirektorPododjela
     */
    DirektorPododjela myDirektorPododjela;
};

#endif // Pododjel_h
