#ifndef Posao_h
#define Posao_h

#include <vector>


class Zaposlenik;

class Posao {

 public:

    /**
     * @element-type Zaposlenik
     */
    std::vector< Zaposlenik* > myZaposlenik;
};

#endif // Posao_h
