#ifndef Radnik_h
#define Radnik_h

#include "Zaposlenik.h"


class Radnik : public Zaposlenik {

};

#endif // Radnik_h
