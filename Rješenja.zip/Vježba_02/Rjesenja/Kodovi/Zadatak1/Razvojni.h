#ifndef Razvojni_h
#define Razvojni_h

#include "Posao.h"
#include "string.h"


class Razvojni : public Posao {

 public:
    string OIB;
};

#endif // Razvojni_h
