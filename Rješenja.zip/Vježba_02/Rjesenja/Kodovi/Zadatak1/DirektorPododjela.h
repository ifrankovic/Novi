#ifndef DirektorPododjela_h
#define DirektorPododjela_h

#include "Direktor.h"
#include "bool.h"


class DirektorPododjela : public Direktor {

 public:

    virtual bool upitDO();

};

#endif // DirektorPododjela_h
