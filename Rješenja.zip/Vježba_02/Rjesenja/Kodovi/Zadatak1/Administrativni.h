#ifndef Administrativni_h
#define Administrativni_h

#include "Posao.h"


class Administrativni : public Posao {};

#endif // Administrativni_h
