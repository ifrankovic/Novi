#ifndef Odjel_h
#define Odjel_h

#include "Pododjel.h"
#include "string.h"


class Odjel {

 public:
    string nazivOdjela;
    string adresaOdjela;

 public:


    /**
     * @element-type Pododjel
     */
    Pododjel myPododjel;
};

#endif // Odjel_h
