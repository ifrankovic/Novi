#ifndef Poduzece_h
#define Poduzece_h

#include "Odjel.h"
#include "int.h"
#include "string.h"


class Poduzece {

 public:
    string OIB;
    string brRacuna;
    int brZaposlenika;

 public:

    /**
     * @element-type Odjel
     */
    Odjel myOdjel;
};

#endif // Poduzece_h
