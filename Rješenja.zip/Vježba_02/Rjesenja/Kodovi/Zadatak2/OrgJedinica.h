#ifndef OrgJedinica_h
#define OrgJedinica_h


class OrgJedinica {

 public:

    virtual void izracunCijene()  = 0;

public:
    // virtual destructor for interface 
    virtual ~OrgJedinica() { }
};

#endif // OrgJedinica_h
