#ifndef OdjelNabave_h
#define OdjelNabave_h

#include <vector>

#include "OrgJedinica.h"
#include "double.h"

class RadnikNabave;
class Sef;
class Knjiga;

class OdjelNabave : virtual public OrgJedinica, virtual public OrgJedinica {

 public:

    virtual double izracunCijene();

 public:


    /**
     * @element-type RadnikNabave
     */
    std::vector< RadnikNabave* > myRadnikNabave;

    Sef *mySef;

    /**
     * @element-type Knjiga
     */
    std::vector< Knjiga* > myKnjiga;
};

#endif // OdjelNabave_h
