#ifndef Knjiga_h
#define Knjiga_h

#include "string.h"

class Polica;
class OdjelNabave;
class Kupac;

/*
 */
class Knjiga {

 public:
    string ISBN;
    string naziv;

 public:

    Polica *myPolica;

    OdjelNabave *myOdjelNabave;

    /**
     * @element-type Kupac
     */
    Kupac *myKupac;
};

#endif // Knjiga_h
