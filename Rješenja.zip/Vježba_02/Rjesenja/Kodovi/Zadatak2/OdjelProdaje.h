#ifndef OdjelProdaje_h
#define OdjelProdaje_h

#include <vector>

#include "OrgJedinica.h"
#include "double.h"

class RadnikProdaje;
class Sef;
class Polica;

class OdjelProdaje : virtual public OrgJedinica {

 public:

    virtual double izracunCijene();

 public:

    /**
     * @element-type RadnikProdaje
     */
    std::vector< RadnikProdaje* > myRadnikProdaje;

    Sef *mySef;

    /**
     * @element-type Polica
     */
    std::vector< Polica* > myPolica;

};

#endif // OdjelProdaje_h
