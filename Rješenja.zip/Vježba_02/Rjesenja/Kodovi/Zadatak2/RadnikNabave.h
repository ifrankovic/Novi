#ifndef RadnikNabave_h
#define RadnikNabave_h

#include "Radnik.h"

class OdjelNabave;

class RadnikNabave : public Radnik {

 public:

    OdjelNabave *myOdjelNabave;
};

#endif // RadnikNabave_h
