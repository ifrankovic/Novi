#ifndef Polica_h
#define Polica_h

#include <vector>


class OdjelProdaje;
class Knjiga;

class Polica {

 public:

    OdjelProdaje *myOdjelProdaje;

    /**
     * @element-type Knjiga
     */
    std::vector< Knjiga* > myKnjiga;
};

#endif // Polica_h
