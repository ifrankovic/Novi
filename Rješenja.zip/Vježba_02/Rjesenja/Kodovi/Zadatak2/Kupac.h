#ifndef Kupac_h
#define Kupac_h

#include "bool.h"
#include "void.h"

class RadnikProdaje;
class Knjiga;

class Kupac {

 public:

    virtual void konzultirajSe();

    virtual bool kupnjaKnjige();

 public:

    RadnikProdaje *myRadnikProdaje;

    /**
     * @element-type Knjiga
     */
    Knjiga *myKnjiga;
};

#endif // Kupac_h
