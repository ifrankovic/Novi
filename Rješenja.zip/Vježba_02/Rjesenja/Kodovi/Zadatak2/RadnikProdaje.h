#ifndef RadnikProdaje_h
#define RadnikProdaje_h

#include <vector>

#include "Radnik.h"
#include "bool.h"
#include "void.h"

class OdjelProdaje;
class Kupac;

class RadnikProdaje : public Radnik, public Radnik {

 public:

    virtual void savjetKupcu();

    virtual bool naplata();

 public:

    OdjelProdaje *myOdjelProdaje;

    /**
     * @element-type Kupac
     */
    std::vector< Kupac* > myKupac;
};

#endif // RadnikProdaje_h
