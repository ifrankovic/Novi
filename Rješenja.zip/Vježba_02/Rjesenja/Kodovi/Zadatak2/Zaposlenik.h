#ifndef Zaposlenik_h
#define Zaposlenik_h

#include "double.h"


class Zaposlenik {

 public:

    virtual double izracunPlace();
};

#endif // Zaposlenik_h
