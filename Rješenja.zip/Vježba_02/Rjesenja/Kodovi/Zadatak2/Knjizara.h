#ifndef Knjizara_h
#define Knjizara_h

#include "OdjelNabave.h"
#include "OdjelProdaje.h"


class Knjizara {

 public:

    /**
     * @element-type OdjelNabave
     */
    OdjelNabave myOdjelNabave;

    OdjelProdaje myOdjelProdaje;
};

#endif // Knjizara_h
