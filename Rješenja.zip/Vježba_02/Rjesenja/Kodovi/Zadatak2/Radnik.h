#ifndef Radnik_h
#define Radnik_h

#include "Zaposlenik.h"
#include "double.h"
#include "void.h"


class Radnik : public Zaposlenik {

 public:

    virtual void konzultacijeSaSefom();

    virtual double izracunPlace();
};

#endif // Radnik_h
