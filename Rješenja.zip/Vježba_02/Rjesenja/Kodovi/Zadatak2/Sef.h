#ifndef Sef_h
#define Sef_h

#include "Zaposlenik.h"
#include "void.h"

class OdjelNabave;
class OdjelProdaje;

class Sef : public Zaposlenik {

 public:

    virtual void vodiJedinicu();

 public:

    OdjelNabave *myOdjelNabave;

    OdjelProdaje *myOdjelProdaje;
};

#endif // Sef_h
