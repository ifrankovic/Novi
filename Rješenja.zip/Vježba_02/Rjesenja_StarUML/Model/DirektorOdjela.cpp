/**
 * Project Untitled
 */


#include "DirektorOdjela.h"

/**
 * DirektorOdjela implementation
 */


/**
 * @return void
 */
void DirektorOdjela::zaposliDPO() {
    return;
}

/**
 * @return void
 */
void DirektorOdjela::otpustiDPO() {
    return;
}

/**
 * @return void
 */
void DirektorOdjela::zaposliRadnika() {
    return;
}

/**
 * @return void
 */
void DirektorOdjela::otpustiRadnika() {
    return;
}