/**
 * Project Untitled
 */


#ifndef _STUDENT_H
#define _STUDENT_H

#include "Osoba.h"


class Student: public Osoba {
public: 
	long JMBAG;
};

#endif //_STUDENT_H