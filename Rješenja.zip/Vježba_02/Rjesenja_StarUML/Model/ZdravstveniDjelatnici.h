/**
 * Project Untitled
 */


#ifndef _ZDRAVSTVENIDJELATNICI_H
#define _ZDRAVSTVENIDJELATNICI_H

#include "Zaposlenici.h"


class ZdravstveniDjelatnici: public Zaposlenici {
public: 
	
	int getSoba();
};

#endif //_ZDRAVSTVENIDJELATNICI_H