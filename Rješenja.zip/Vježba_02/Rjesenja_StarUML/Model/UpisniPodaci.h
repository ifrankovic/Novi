/**
 * Project Untitled
 */


#ifndef _UPISNIPODACI_H
#define _UPISNIPODACI_H

class UpisniPodaci {
};

#endif //_UPISNIPODACI_H