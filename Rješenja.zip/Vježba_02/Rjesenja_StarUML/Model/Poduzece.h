/**
 * Project Untitled
 */


#ifndef _PODUZECE_H
#define _PODUZECE_H

class Poduzece {
public: 
	string maticniBrojPoduzeca;
	void brRačuna. string;
	int brZaposlenika;
};

#endif //_PODUZECE_H