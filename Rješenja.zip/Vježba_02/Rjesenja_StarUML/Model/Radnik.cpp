/**
 * Project Untitled
 */


#include "Radnik.h"

/**
 * Radnik implementation
 */


/**
 * @return void
 */
void Radnik::konzultscijeSaSefom() {
    return;
}