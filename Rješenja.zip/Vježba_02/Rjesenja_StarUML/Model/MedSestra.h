/**
 * Project Untitled
 */


#ifndef _MEDSESTRA_H
#define _MEDSESTRA_H

#include "ZdravstveniDjelatnici.h"


class MedSestra: public ZdravstveniDjelatnici {
public: 
	
	void mjerenjeTlaka();
};

#endif //_MEDSESTRA_H