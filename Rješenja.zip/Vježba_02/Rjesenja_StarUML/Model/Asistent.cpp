/**
 * Project Untitled
 */


#include "Asistent.h"

/**
 * Asistent implementation
 */
