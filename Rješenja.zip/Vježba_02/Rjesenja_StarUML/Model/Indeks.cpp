/**
 * Project Untitled
 */


#include "Indeks.h"

/**
 * Indeks implementation
 */
