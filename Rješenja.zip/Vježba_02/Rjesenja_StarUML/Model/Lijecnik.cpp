/**
 * Project Untitled
 */


#include "Lijecnik.h"

/**
 * Lijecnik implementation
 */


void Lijecnik::postavljanjeDijagnoze() {

}