/**
 * Project Untitled
 */


#include "ONabave.h"

/**
 * ONabave implementation
 */


/**
 * @return double
 */
double ONabave::izracunajCijenu() {
    return 0.0;
}