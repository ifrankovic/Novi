/**
 * Project Untitled
 */


#include "Sef.h"

/**
 * Sef implementation
 */


/**
 * @return void
 */
void Sef::vodiJedinicu() {
    return;
}