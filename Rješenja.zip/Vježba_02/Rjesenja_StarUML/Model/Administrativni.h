/**
 * Project Untitled
 */


#ifndef _ADMINISTRATIVNI_H
#define _ADMINISTRATIVNI_H

#include "Posao.h"


class Administrativni: public Posao {
};

#endif //_ADMINISTRATIVNI_H