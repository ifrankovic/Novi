/**
 * Project Untitled
 */


#include "RadnikProdaje.h"

/**
 * RadnikProdaje implementation
 */


/**
 * @return void
 */
void RadnikProdaje::savjetujeKupca() {
    return;
}

/**
 * @return boolean
 */
boolean RadnikProdaje::naplataknjiga() {
    return false;
}