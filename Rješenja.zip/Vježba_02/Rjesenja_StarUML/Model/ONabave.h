/**
 * Project Untitled
 */


#ifndef _ONABAVE_H
#define _ONABAVE_H

#include "Interface1.h"
#include "Sef.h"


class ONabave: public Interface1 {
public: 
	Sef upravlja;
	
	double izracunajCijenu();
};

#endif //_ONABAVE_H