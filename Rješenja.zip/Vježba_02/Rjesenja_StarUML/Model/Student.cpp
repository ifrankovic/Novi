/**
 * Project Untitled
 */


#include "Student.h"

/**
 * Student implementation
 */
