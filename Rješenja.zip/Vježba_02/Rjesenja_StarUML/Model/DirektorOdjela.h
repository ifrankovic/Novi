/**
 * Project Untitled
 */


#ifndef _DIREKTORODJELA_H
#define _DIREKTORODJELA_H

#include "Direktor.h"


class DirektorOdjela: public Direktor {
public: 
	
	void zaposliDPO();
	
	void otpustiDPO();
	
	void zaposliRadnika();
	
	void otpustiRadnika();
};

#endif //_DIREKTORODJELA_H