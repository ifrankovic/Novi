/**
 * Project Untitled
 */


#ifndef _PROFESOR_H
#define _PROFESOR_H

#include "SveucilisniDjelatnici.h"


class Profesor: public SveucilisniDjelatnici {
};

#endif //_PROFESOR_H