/**
 * Project Untitled
 */


#ifndef _SEF_H
#define _SEF_H

#include "Zaposlenik.h"


class Sef: public Zaposlenik {
public: 
	
	void vodiJedinicu();
};

#endif //_SEF_H