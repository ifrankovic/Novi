/**
 * Project Untitled
 */


#ifndef _KUPAC_H
#define _KUPAC_H

class Kupac {
public: 
	
	void konzultirajSe();
	
	bool kupiKnjihu();
};

#endif //_KUPAC_H