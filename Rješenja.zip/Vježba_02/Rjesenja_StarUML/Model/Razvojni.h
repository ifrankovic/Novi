/**
 * Project Untitled
 */


#ifndef _RAZVOJNI_H
#define _RAZVOJNI_H

#include "Posao.h"


class Razvojni: public Posao {
public: 
	string MBPoduzeca;
};

#endif //_RAZVOJNI_H