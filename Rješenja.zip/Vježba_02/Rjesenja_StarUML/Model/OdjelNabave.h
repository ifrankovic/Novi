/**
 * Project Untitled
 */


#ifndef _ODJELNABAVE_H
#define _ODJELNABAVE_H

class OdjelNabave {
};

#endif //_ODJELNABAVE_H