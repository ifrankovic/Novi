/**
 * Project Untitled
 */


#include "ZdravstveniDjelatnici.h"

/**
 * ZdravstveniDjelatnici implementation
 */


/**
 * @return int
 */
int ZdravstveniDjelatnici::getSoba() {
    return 0;
}