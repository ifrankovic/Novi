/**
 * Project Untitled
 */


#include "MedSestra.h"

/**
 * MedSestra implementation
 */


void MedSestra::mjerenjeTlaka() {

}