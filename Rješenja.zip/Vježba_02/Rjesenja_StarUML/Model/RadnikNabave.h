/**
 * Project Untitled
 */


#ifndef _RADNIKNABAVE_H
#define _RADNIKNABAVE_H

#include "Radnik.h"


class RadnikNabave: public Radnik {
};

#endif //_RADNIKNABAVE_H