/**
 * Project Untitled
 */


#include "Osoba.h"

/**
 * Osoba implementation
 */
