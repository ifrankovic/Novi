/**
 * Project Untitled
 */


#include "Administrativni.h"

/**
 * Administrativni implementation
 */
