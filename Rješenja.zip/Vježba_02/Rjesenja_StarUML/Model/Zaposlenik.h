/**
 * Project Untitled
 */


#ifndef _ZAPOSLENIK_H
#define _ZAPOSLENIK_H

class Zaposlenik {
public: 
	string ime;
	string prezime;
private: 
	int OIB;
};

#endif //_ZAPOSLENIK_H