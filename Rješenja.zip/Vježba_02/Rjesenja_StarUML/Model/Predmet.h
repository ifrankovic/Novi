/**
 * Project Untitled
 */


#ifndef _PREDMET_H
#define _PREDMET_H

class Predmet {
};

#endif //_PREDMET_H