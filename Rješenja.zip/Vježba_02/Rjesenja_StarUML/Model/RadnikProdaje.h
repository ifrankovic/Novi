/**
 * Project Untitled
 */


#ifndef _RADNIKPRODAJE_H
#define _RADNIKPRODAJE_H

#include "Radnik.h"


class RadnikProdaje: public Radnik {
public: 
	
	void savjetujeKupca();
	
	boolean naplataknjiga();
};

#endif //_RADNIKPRODAJE_H