/**
 * Project Untitled
 */


#ifndef _INDEKS_H
#define _INDEKS_H

#include "Student.h"


class Indeks {
public: 
	Student 1;
};

#endif //_INDEKS_H