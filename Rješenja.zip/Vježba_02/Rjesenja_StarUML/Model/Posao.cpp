/**
 * Project Untitled
 */


#include "Posao.h"

/**
 * Posao implementation
 */
