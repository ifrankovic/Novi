/**
 * Project Untitled
 */


#ifndef _ODJEL_H
#define _ODJEL_H

class Odjel {
public: 
	string nazivOdjela;
	string adresaOdjela;
};

#endif //_ODJEL_H