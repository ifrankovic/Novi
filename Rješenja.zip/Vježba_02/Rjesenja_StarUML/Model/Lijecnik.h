/**
 * Project Untitled
 */


#ifndef _LIJECNIK_H
#define _LIJECNIK_H

#include "ZdravstveniDjelatnici.h"


class Lijecnik: public ZdravstveniDjelatnici {
public: 
	
	void postavljanjeDijagnoze();
};

#endif //_LIJECNIK_H