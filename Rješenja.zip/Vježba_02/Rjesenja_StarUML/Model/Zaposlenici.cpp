/**
 * Project Untitled
 */


#include "Zaposlenici.h"

/**
 * Zaposlenici implementation
 */


/**
 * @param sifra
 * @return void
 */
void Zaposlenici::setSifra(void sifra) {
    return;
}

/**
 * @return int
 */
int Zaposlenici::getSifra() {
    return 0;
}

/**
 * @return int
 */
int Zaposlenici::getSoba() {
    return 0;
}