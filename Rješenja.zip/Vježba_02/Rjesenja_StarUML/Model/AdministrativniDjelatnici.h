/**
 * Project Untitled
 */


#ifndef _ADMINISTRATIVNIDJELATNICI_H
#define _ADMINISTRATIVNIDJELATNICI_H

#include "Zaposlenici.h"


class AdministrativniDjelatnici: public Zaposlenici {
};

#endif //_ADMINISTRATIVNIDJELATNICI_H