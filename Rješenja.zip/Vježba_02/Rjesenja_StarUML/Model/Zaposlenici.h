/**
 * Project Untitled
 */


#ifndef _ZAPOSLENICI_H
#define _ZAPOSLENICI_H

class Zaposlenici {
public: 
	string ime;
	int soba;
	
	/**
	 * @param sifra
	 */
	void setSifra(void sifra);
	
	int getSifra();
	
	int getSoba();
private: 
	long sifra;
};

#endif //_ZAPOSLENICI_H