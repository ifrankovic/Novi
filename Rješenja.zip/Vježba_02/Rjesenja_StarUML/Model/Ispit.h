/**
 * Project Untitled
 */


#ifndef _ISPIT_H
#define _ISPIT_H

class Ispit {
};

#endif //_ISPIT_H