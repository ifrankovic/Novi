/**
 * Project Untitled
 */


#include "Knjiga.h"

/**
 * Knjiga implementation
 */
