/**
 * Project Untitled
 */


#ifndef _RADNINALOG_H
#define _RADNINALOG_H

class RadniNalog {
};

#endif //_RADNINALOG_H