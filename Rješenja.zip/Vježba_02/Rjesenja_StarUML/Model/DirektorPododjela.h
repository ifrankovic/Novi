/**
 * Project Untitled
 */


#ifndef _DIREKTORPODODJELA_H
#define _DIREKTORPODODJELA_H

#include "Direktor.h"


class DirektorPododjela: public Direktor {
public: 
	
	boolean upitDO();
};

#endif //_DIREKTORPODODJELA_H