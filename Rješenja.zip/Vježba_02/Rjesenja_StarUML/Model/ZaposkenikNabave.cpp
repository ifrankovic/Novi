/**
 * Project Untitled
 */


#include "ZaposkenikNabave.h"

/**
 * ZaposkenikNabave implementation
 */


/**
 * @return double
 */
double ZaposkenikNabave::nabaviMaterijal() {
    return 0.0;
}

/**
 * @return double
 */
double ZaposkenikNabave::izracunajPlacu() {
    return 0.0;
}