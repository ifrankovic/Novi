/**
 * Project Untitled
 */


#include "Organizacija.h"

/**
 * Organizacija implementation
 */
