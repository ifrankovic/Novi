/**
 * Project Untitled
 */


#include "Direktor.h"

/**
 * Direktor implementation
 */
