/**
 * Project Untitled
 */


#include "Zaposlenik.h"

/**
 * Zaposlenik implementation
 */
