/**
 * Project Untitled
 */


#include "OProdaje.h"

/**
 * OProdaje implementation
 */


/**
 * @return double
 */
double OProdaje::izracunajCijenu() {
    return 0.0;
}