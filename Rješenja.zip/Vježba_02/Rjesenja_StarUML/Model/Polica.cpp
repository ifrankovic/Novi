/**
 * Project Untitled
 */


#include "Polica.h"

/**
 * Polica implementation
 */
