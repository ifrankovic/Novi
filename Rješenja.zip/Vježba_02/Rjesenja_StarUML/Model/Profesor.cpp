/**
 * Project Untitled
 */


#include "Profesor.h"

/**
 * Profesor implementation
 */
