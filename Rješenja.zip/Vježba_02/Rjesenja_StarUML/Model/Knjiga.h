/**
 * Project Untitled
 */


#ifndef _KNJIGA_H
#define _KNJIGA_H

class Knjiga {
public: 
	string ISBN;
	string naziv;
};

#endif //_KNJIGA_H