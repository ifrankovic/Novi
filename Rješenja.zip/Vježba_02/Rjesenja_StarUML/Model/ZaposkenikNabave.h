/**
 * Project Untitled
 */


#ifndef _ZAPOSKENIKNABAVE_H
#define _ZAPOSKENIKNABAVE_H

#include "Zaposlenik.h"


class ZaposkenikNabave: public Zaposlenik {
public: 
	
	double nabaviMaterijal();
	
	double izracunajPlacu();
};

#endif //_ZAPOSKENIKNABAVE_H