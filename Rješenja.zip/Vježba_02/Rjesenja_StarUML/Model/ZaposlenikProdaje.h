/**
 * Project Untitled
 */


#ifndef _ZAPOSLENIKPRODAJE_H
#define _ZAPOSLENIKPRODAJE_H

#include "Zaposlenik.h"


class ZaposlenikProdaje: public Zaposlenik {
public: 
	
	double prodajProizvod();
	
	double izracunajPlacu();
};

#endif //_ZAPOSLENIKPRODAJE_H