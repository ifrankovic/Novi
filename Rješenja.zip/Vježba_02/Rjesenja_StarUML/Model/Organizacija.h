/**
 * Project Untitled
 */


#ifndef _ORGANIZACIJA_H
#define _ORGANIZACIJA_H

class Organizacija {
};

#endif //_ORGANIZACIJA_H