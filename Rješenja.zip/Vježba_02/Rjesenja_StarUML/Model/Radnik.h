/**
 * Project Untitled
 */


#ifndef _RADNIK_H
#define _RADNIK_H

#include "Zaposlenik.h"


class Radnik: public Zaposlenik {
public: 
	
	void konzultscijeSaSefom();
};

#endif //_RADNIK_H