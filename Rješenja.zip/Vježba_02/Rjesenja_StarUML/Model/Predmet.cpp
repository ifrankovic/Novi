/**
 * Project Untitled
 */


#include "Predmet.h"

/**
 * Predmet implementation
 */
