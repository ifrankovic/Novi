/**
 * Project Untitled
 */


#ifndef _POSAO_H
#define _POSAO_H

class Posao {
public: 
	string naziv;
	date rokDovrsenja;
};

#endif //_POSAO_H