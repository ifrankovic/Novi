/**
 * Project Untitled
 */


#include "Rektor.h"

/**
 * Rektor implementation
 */


void Rektor::nagradi() {

}

void Rektor::promakni() {

}