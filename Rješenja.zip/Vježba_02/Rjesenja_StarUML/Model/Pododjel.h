/**
 * Project Untitled
 */


#ifndef _PODODJEL_H
#define _PODODJEL_H

class Pododjel {
public: 
	string nazivOdjela;
	string adresaOdjela;
	string nazivPO;
};

#endif //_PODODJEL_H