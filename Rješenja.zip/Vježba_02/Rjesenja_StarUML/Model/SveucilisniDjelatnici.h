/**
 * Project Untitled
 */


#ifndef _SVEUCILISNIDJELATNICI_H
#define _SVEUCILISNIDJELATNICI_H

class SveucilisniDjelatnici {
};

#endif //_SVEUCILISNIDJELATNICI_H