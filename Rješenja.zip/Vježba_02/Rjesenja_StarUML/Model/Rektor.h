/**
 * Project Untitled
 */


#ifndef _REKTOR_H
#define _REKTOR_H

#include "SveucilisniDjelatnici.h"


class Rektor: public SveucilisniDjelatnici {
public: 
	
	void nagradi();
	
	void promakni();
};

#endif //_REKTOR_H