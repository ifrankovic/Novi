/**
 * Project Untitled
 */


#ifndef _OSOBA_H
#define _OSOBA_H

class Osoba {
public: 
	long OIB;
	string ime;
	string prezime;
};

#endif //_OSOBA_H