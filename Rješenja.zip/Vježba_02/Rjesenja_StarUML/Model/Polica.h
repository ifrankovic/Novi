/**
 * Project Untitled
 */


#ifndef _POLICA_H
#define _POLICA_H

class Polica {
};

#endif //_POLICA_H