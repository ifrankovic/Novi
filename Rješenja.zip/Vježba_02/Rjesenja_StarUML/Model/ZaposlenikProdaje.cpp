/**
 * Project Untitled
 */


#include "ZaposlenikProdaje.h"

/**
 * ZaposlenikProdaje implementation
 */


/**
 * @return double
 */
double ZaposlenikProdaje::prodajProizvod() {
    return 0.0;
}

/**
 * @return double
 */
double ZaposlenikProdaje::izracunajPlacu() {
    return 0.0;
}