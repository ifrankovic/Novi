/**
 * Project Untitled
 */


#ifndef _OPRODAJE_H
#define _OPRODAJE_H

#include "Interface1.h"
#include "Sef.h"


class OProdaje: public Interface1 {
public: 
	Sef upravlja;
	
	double izracunajCijenu();
};

#endif //_OPRODAJE_H