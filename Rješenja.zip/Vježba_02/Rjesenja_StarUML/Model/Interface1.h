/**
 * Project Untitled
 */


#ifndef _INTERFACE1_H
#define _INTERFACE1_H

class Interface1 {
public: 
	
	double izracunajCijenu();
};

#endif //_INTERFACE1_H