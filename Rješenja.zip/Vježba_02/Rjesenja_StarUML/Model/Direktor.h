/**
 * Project Untitled
 */


#ifndef _DIREKTOR_H
#define _DIREKTOR_H

class Direktor {
};

#endif //_DIREKTOR_H