/**
 * Project Untitled
 */


#ifndef _ASISTENT_H
#define _ASISTENT_H

#include "SveucilisniDjelatnici.h"


class Asistent: public SveucilisniDjelatnici {
};

#endif //_ASISTENT_H