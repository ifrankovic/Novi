/**
 * Project Untitled
 */


#include "DirektorPododjela.h"

/**
 * DirektorPododjela implementation
 */


/**
 * @return boolean
 */
boolean DirektorPododjela::upitDO() {
    return false;
}