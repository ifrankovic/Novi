/**
 * Project Untitled
 */


#include "Kupac.h"

/**
 * Kupac implementation
 */


/**
 * @return void
 */
void Kupac::konzultirajSe() {
    return;
}

/**
 * @return bool
 */
bool Kupac::kupiKnjihu() {
    return false;
}