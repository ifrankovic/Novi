/**
 * Project Untitled
 */


#ifndef _STUDENT_H
#define _STUDENT_H

class Student {
public: 
	long ID;
	
	/**
	 * @param ID
	 */
	boolean prijavaIspita(int ID);
	
	/**
	 * @param ID
	 */
	boolean odjavaIspita(integer ID);
	
	/**
	 * @param ID
	 */
	boolean pristupIspitu(integer ID);
private: 
	string ime;
	string prezime;
	double prosjekOcjena;
};

#endif //_STUDENT_H