/**
 * Project Untitled
 */


#include "Student.h"

/**
 * Student implementation
 */


/**
 * @param ID
 * @return boolean
 */
boolean Student::prijavaIspita(int ID) {
    return false;
}

/**
 * @param ID
 * @return boolean
 */
boolean Student::odjavaIspita(integer ID) {
    return false;
}

/**
 * @param ID
 * @return boolean
 */
boolean Student::pristupIspitu(integer ID) {
    return false;
}