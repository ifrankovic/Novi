#include <vector>
using namespace std;

#ifndef __Polica_h__
#define __Polica_h__

// #include "OJProdaje.h"
#include "Knjiga.h"

class OJProdaje;
class Knjiga;
class Polica;

class Polica
{
	public: OJProdaje* _unnamed_OJProdaje_;
	public: std::vector<Knjiga*> _unnamed_Knjiga_;
};

#endif
