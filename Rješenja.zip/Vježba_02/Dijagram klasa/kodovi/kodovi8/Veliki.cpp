#include <exception>
using namespace std;

#include "Veliki.h"
#include "Osoba.h"

void Veliki::operation() {
	throw "Not yet implemented";
}

