
#ifndef __Organizacija_h__
#define __Organizacija_h__

// #include "OdjelNabave.h"
// #include "OdjelProdaje.h"

class OdjelNabave;
class OdjelProdaje;
class Organizacija;

class Organizacija
{
	public: OdjelNabave* _unnamed_OdjelNabave_;
	public: OdjelProdaje* _unnamed_OdjelProdaje_;
};

#endif
