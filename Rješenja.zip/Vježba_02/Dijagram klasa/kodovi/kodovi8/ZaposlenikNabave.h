#include <exception>
using namespace std;

#ifndef __ZaposlenikNabave_h__
#define __ZaposlenikNabave_h__

// #include "OdjelNabave.h"
#include "Zaposlenik.h"

class OdjelNabave;
// class Zaposlenik;
class ZaposlenikNabave;

class ZaposlenikNabave: public Zaposlenik
{
	public: OdjelNabave* _unnamed_OdjelNabave_;

	public: double nabaviMaterijal();

	public: double izracunajPlacu();
};

#endif
