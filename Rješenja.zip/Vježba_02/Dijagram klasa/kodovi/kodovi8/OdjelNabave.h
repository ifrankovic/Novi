
#ifndef __OdjelNabave_h__
#define __OdjelNabave_h__

// #include "Organizacija.h"
// #include "ZaposlenikNabave.h"

class Organizacija;
class ZaposlenikNabave;
class OdjelNabave;

class OdjelNabave
{
	public: Organizacija* _unnamed_Organizacija_;
	public: ZaposlenikNabave* _unnamed_ZaposlenikNabave_;
};

#endif
