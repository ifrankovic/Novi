
#ifndef __OdjelProdaje_h__
#define __OdjelProdaje_h__

// #include "Organizacija.h"
// #include "ZaposlenikProdaje.h"

class Organizacija;
class ZaposlenikProdaje;
class OdjelProdaje;

class OdjelProdaje
{
	public: Organizacija* _unnamed_Organizacija_;
	public: ZaposlenikProdaje* _unnamed_ZaposlenikProdaje_;
};

#endif
