#include <exception>
using namespace std;

#include "ZaposlenikNabave.h"
#include "OdjelNabave.h"
#include "Zaposlenik.h"

double ZaposlenikNabave::nabaviMaterijal() {
	throw "Not yet implemented";
}

double ZaposlenikNabave::izracunajPlacu() {
	throw "Not yet implemented";
}

