#include <exception>
using namespace std;

#ifndef __Zaposlenik_h__
#define __Zaposlenik_h__

class Zaposlenik;

class Zaposlenik
{

	public: double izracunajPlacu();
};

#endif
