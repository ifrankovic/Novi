#include <exception>
using namespace std;

#include "ZaposlenikProdaje.h"
#include "OdjelProdaje.h"
#include "Zaposlenik.h"

double ZaposlenikProdaje::prodajProizvod() {
	throw "Not yet implemented";
}

double ZaposlenikProdaje::izracunajPlacu() {
	throw "Not yet implemented";
}

