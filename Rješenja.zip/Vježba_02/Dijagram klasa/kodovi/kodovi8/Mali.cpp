#include <exception>
using namespace std;

#include "Mali.h"
#include "Osoba.h"

void Mali::operation() {
	throw "Not yet implemented";
}

