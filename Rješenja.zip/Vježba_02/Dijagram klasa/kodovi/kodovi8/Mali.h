#include <exception>
using namespace std;

#ifndef __Mali_h__
#define __Mali_h__

#include "Osoba.h"

// class Osoba;
class Mali;

class Mali: public Osoba
{

	public: void operation();
};

#endif
