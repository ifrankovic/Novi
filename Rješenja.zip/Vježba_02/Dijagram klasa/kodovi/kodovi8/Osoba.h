#include <exception>
#include <string>
using namespace std;

#ifndef __Osoba_h__
#define __Osoba_h__

class Osoba;

class Osoba
{
	private: string _oIB;
	public: string _ime;
	public: string _prezime;

	public: void operation();
};

#endif
