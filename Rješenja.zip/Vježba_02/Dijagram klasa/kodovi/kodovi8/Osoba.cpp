#include <exception>
#include <string>
using namespace std;

#include "Osoba.h"
void Osoba::operation() {
	throw "Not yet implemented";
}

