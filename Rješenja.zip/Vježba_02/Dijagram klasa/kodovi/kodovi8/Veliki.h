#include <exception>
using namespace std;

#ifndef __Veliki_h__
#define __Veliki_h__

#include "Osoba.h"

// class Osoba;
class Veliki;

class Veliki: public Osoba
{

	public: void operation();
};

#endif
