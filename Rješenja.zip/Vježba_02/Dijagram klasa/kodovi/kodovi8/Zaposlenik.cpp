#include <exception>
using namespace std;

#include "Zaposlenik.h"
double Zaposlenik::izracunajPlacu() {
	throw "Not yet implemented";
}

