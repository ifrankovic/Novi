#include <exception>
using namespace std;

#ifndef __ZaposlenikProdaje_h__
#define __ZaposlenikProdaje_h__

// #include "OdjelProdaje.h"
#include "Zaposlenik.h"

class OdjelProdaje;
// class Zaposlenik;
class ZaposlenikProdaje;

class ZaposlenikProdaje: public Zaposlenik
{
	public: OdjelProdaje* _unnamed_OdjelProdaje_;

	public: double prodajProizvod();

	public: double izracunajPlacu();
};

#endif
