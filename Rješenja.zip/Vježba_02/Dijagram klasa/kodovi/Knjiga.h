#include <string>
using namespace std;

#ifndef __Knjiga_h__
#define __Knjiga_h__

// #include "OJNabave.h"
// #include "Polica.h"
// #include "Kupac.h"

class OJNabave;
class Polica;
class Kupac;
class Knjiga;

class Knjiga
{
	private: string _iSBN;
	public: string _naziv;
	public: OJNabave* _unnamed_OJNabave_;
	public: Polica* _unnamed_Polica_;
	public: Kupac* _unnamed_Kupac_;
};

#endif
