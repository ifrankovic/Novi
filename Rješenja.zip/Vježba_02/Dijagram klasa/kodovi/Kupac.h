#include <exception>
using namespace std;

#ifndef __Kupac_h__
#define __Kupac_h__

// #include "RadnikProdaje.h"
// #include "Knjiga.h"

class RadnikProdaje;
class Knjiga;
class Kupac;

class Kupac
{
	public: RadnikProdaje* _unnamed_RadnikProdaje_;
	public: Knjiga* _unnamed_Knjiga_;

	public: void konzultirajSe();

	public: bool kupiKnjigu();
};

#endif
