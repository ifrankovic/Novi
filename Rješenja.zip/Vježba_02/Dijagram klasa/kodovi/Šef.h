#include <exception>
using namespace std;

#ifndef __�ef_h__
#define __�ef_h__

// #include "OJProdaje.h"
// #include "OJNabave.h"
#include "Zaposlenik.h"

class OJProdaje;
class OJNabave;
// class Zaposlenik;
class �ef;

class �ef: public Zaposlenik
{
	public: OJProdaje* _unnamed_OJProdaje_;
	public: OJNabave* _unnamed_OJNabave_;

	public: void vodiJedinicu();

	public: double izracunajPlacu();
};

#endif
