#include <exception>
using namespace std;

#ifndef __Radnik_h__
#define __Radnik_h__

#include "Zaposlenik.h"

// class Zaposlenik;
class Radnik;

class Radnik: public Zaposlenik
{

	public: void konzultirajSeSaSefom();

	public: double izracunajPlacu();
};

#endif
