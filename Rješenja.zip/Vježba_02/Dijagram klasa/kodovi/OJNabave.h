#include <exception>
#include <vector>
using namespace std;

#ifndef __OJNabave_h__
#define __OJNabave_h__

// #include "Knji�ara.h"
// #include "�ef.h"
#include "Knjiga.h"
#include "RadnikNabave.h"
#include "OrgJedinica.h"

class Knji�ara;
class �ef;
class Knjiga;
class RadnikNabave;
// __interface OrgJedinica;
class OJNabave;

class OJNabave: public OrgJedinica
{
	public: Knji�ara* _unnamed_Knji�ara_;
	public: �ef* _unnamed_�ef_;
	public: std::vector<Knjiga*> _unnamed_Knjiga_;
	public: std::vector<RadnikNabave*> _unnamed_RadnikNabave_;

	public: double izracunajCijenu();
};

#endif
