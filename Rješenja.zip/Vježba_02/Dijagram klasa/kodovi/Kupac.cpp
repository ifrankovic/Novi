#include <exception>
using namespace std;

#include "Kupac.h"
#include "RadnikProdaje.h"
#include "Knjiga.h"

void Kupac::konzultirajSe() {
	throw "Not yet implemented";
}

bool Kupac::kupiKnjigu() {
	throw "Not yet implemented";
}

