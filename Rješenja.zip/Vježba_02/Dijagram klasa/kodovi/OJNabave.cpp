#include <exception>
#include <vector>
using namespace std;

#include "OJNabave.h"
#include "Knji�ara.h"
#include "�ef.h"
#include "Knjiga.h"
#include "RadnikNabave.h"
#include "OrgJedinica.h"

double OJNabave::izracunajCijenu() {
	throw "Not yet implemented";
}

