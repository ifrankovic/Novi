#include <exception>
using namespace std;

#include "�ef.h"
#include "OJProdaje.h"
#include "OJNabave.h"
#include "Zaposlenik.h"

void �ef::vodiJedinicu() {
	throw "Not yet implemented";
}

double �ef::izracunajPlacu() {
	throw "Not yet implemented";
}

