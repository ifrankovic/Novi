
#ifndef __RadnikNabave_h__
#define __RadnikNabave_h__

// #include "OJNabave.h"
#include "Radnik.h"

class OJNabave;
// class Radnik;
class RadnikNabave;

class RadnikNabave: public Radnik
{
	public: OJNabave* _unnamed_OJNabave_;
};

#endif
