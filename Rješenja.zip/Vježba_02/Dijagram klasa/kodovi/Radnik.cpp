#include <exception>
using namespace std;

#include "Radnik.h"
#include "Zaposlenik.h"

void Radnik::konzultirajSeSaSefom() {
	throw "Not yet implemented";
}

double Radnik::izracunajPlacu() {
	throw "Not yet implemented";
}

