#include <exception>
#include <vector>
using namespace std;

#ifndef __RadnikProdaje_h__
#define __RadnikProdaje_h__

// #include "OJProdaje.h"
#include "Kupac.h"
#include "Radnik.h"

class OJProdaje;
class Kupac;
// class Radnik;
class RadnikProdaje;

class RadnikProdaje: public Radnik
{
	public: OJProdaje* _unnamed_OJProdaje_;
	public: std::vector<Kupac*> _unnamed_Kupac_;

	public: void savjetujKupca();

	public: bool naplati();
};

#endif
