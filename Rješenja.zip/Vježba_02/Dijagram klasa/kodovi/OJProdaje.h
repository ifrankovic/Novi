#include <exception>
#include <vector>
using namespace std;

#ifndef __OJProdaje_h__
#define __OJProdaje_h__

// #include "Knji�ara.h"
// #include "�ef.h"
#include "Polica.h"
#include "RadnikProdaje.h"
#include "OrgJedinica.h"

class Knji�ara;
class �ef;
class Polica;
class RadnikProdaje;
// __interface OrgJedinica;
class OJProdaje;

class OJProdaje: public OrgJedinica
{
	public: Knji�ara* _unnamed_Knji�ara_;
	public: �ef* _unnamed_�ef_;
	public: std::vector<Polica*> _unnamed_Polica_;
	public: std::vector<RadnikProdaje*> _unnamed_RadnikProdaje_;

	public: double izracunajCijenu();
};

#endif
