#include <exception>
#include <vector>
using namespace std;

#include "OJProdaje.h"
#include "Knji�ara.h"
#include "�ef.h"
#include "Polica.h"
#include "RadnikProdaje.h"
#include "OrgJedinica.h"

double OJProdaje::izracunajCijenu() {
	throw "Not yet implemented";
}

