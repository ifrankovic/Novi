#include <exception>
#include <vector>
using namespace std;

#include "RadnikProdaje.h"
#include "OJProdaje.h"
#include "Kupac.h"
#include "Radnik.h"

void RadnikProdaje::savjetujKupca() {
	throw "Not yet implemented";
}

bool RadnikProdaje::naplati() {
	throw "Not yet implemented";
}

