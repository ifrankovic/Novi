
#ifndef __Knji�ara_h__
#define __Knji�ara_h__

// #include "OJProdaje.h"
// #include "OJNabave.h"

class OJProdaje;
class OJNabave;
class Knji�ara;

class Knji�ara
{
	public: OJProdaje* _unnamed_OJProdaje_;
	public: OJNabave* _unnamed_OJNabave_;
};

#endif
