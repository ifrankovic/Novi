#include <exception>
using namespace std;

#ifndef __OrgJedinica_h__
#define __OrgJedinica_h__

__interface OrgJedinica;

__interface OrgJedinica
{

	public: virtual double izracunajCijenu() = 0;
};

#endif
