#include <string>
using namespace std;

#ifndef __Poduze�e_h__
#define __Poduze�e_h__

// #include "Odjel.h"

class Odjel;
class Poduze�e;

class Poduze�e
{
	private: string _maticniBrojPoduze�a;
	public: string _brRacuna;
	public: int _brZaposlenika;
	public: Odjel* _unnamed_Odjel_;
};

#endif
