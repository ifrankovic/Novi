#include <exception>
using namespace std;

#ifndef __Sucelje_h__
#define __Sucelje_h__

__interface Sucelje;

__interface Sucelje
{

	public: virtual void metodica() = 0;
};

#endif
