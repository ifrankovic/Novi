
#ifndef __Administrativni_h__
#define __Administrativni_h__

#include "Posao.h"

// class Posao;
class Administrativni;

class Administrativni: public Posao
{
};

#endif
