#include <string>
#include <vector>
using namespace std;

#ifndef __Posao_h__
#define __Posao_h__

#include "Zaposlenik.h"

class Zaposlenik;
class Posao;

class Posao
{
	public: string _naziv;
	public: date _rokDovrsenja;
	public: std::vector<Zaposlenik*> _unnamed_Zaposlenik_;
};

#endif
