#include <string>
using namespace std;

#ifndef __Pododjel_h__
#define __Pododjel_h__

// #include "Odjel.h"
// #include "DirektorPododjela.h"
// #include "Radnik.h"

class Odjel;
class DirektorPododjela;
class Radnik;
class Pododjel;

class Pododjel
{
	private: string _nazivOdjela;
	private: string _adresaOdjela;
	private: string _nazivPododjela;
	public: Odjel* _unnamed_Odjel_;
	public: DirektorPododjela* _unnamed_DirektorPododjela_;
	public: Radnik* _unnamed_Radnik_;
};

#endif
