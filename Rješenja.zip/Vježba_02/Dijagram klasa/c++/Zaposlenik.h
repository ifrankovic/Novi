#include <string>
#include <vector>
using namespace std;

#ifndef __Zaposlenik_h__
#define __Zaposlenik_h__

#include "Posao.h"

class Posao;
class Zaposlenik;

class Zaposlenik
{
	private: string _maticniBrojZaposlenika;
	public: string _ime;
	public: string _prezime;
	public: std::vector<Posao*> _unnamed_Posao_;
};

#endif
