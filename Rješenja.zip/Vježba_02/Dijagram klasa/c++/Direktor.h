
#ifndef __Direktor_h__
#define __Direktor_h__

#include "Zaposlenik.h"

// class Zaposlenik;
class Direktor;

class Direktor: public Zaposlenik
{
};

#endif
