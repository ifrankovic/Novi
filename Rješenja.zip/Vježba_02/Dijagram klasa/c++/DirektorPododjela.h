#include <exception>
using namespace std;

#ifndef __DirektorPododjela_h__
#define __DirektorPododjela_h__

// #include "Pododjel.h"
#include "Direktor.h"

class Pododjel;
// class Direktor;
class DirektorPododjela;

class DirektorPododjela: public Direktor
{
	public: Pododjel* _unnamed_Pododjel_;

	public: bool upitZaOtpustanje();
};

#endif
