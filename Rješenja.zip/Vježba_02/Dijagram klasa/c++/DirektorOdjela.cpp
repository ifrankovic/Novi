#include <exception>
using namespace std;

#include "DirektorOdjela.h"
#include "Direktor.h"

void DirektorOdjela::zaposliDPO() {
	throw "Not yet implemented";
}

void DirektorOdjela::otpustiDPO() {
	throw "Not yet implemented";
}

void DirektorOdjela::otpustiRadnika() {
	throw "Not yet implemented";
}

void DirektorOdjela::zaposliRadnika() {
	throw "Not yet implemented";
}

