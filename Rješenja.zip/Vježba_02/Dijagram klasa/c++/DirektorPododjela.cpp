#include <exception>
using namespace std;

#include "DirektorPododjela.h"
#include "Pododjel.h"
#include "Direktor.h"

bool DirektorPododjela::upitZaOtpustanje() {
	throw "Not yet implemented";
}

