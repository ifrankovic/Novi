#include <string>
using namespace std;

#ifndef __Odjel_h__
#define __Odjel_h__

// #include "Poduze�e.h"
// #include "Pododjel.h"

class Poduze�e;
class Pododjel;
class Odjel;

class Odjel
{
	public: string _nazivOdjela;
	public: string _adresaOdjela;
	public: Poduze�e* _unnamed_Poduze�e_;
	public: Pododjel* _unnamed_Pododjel_;
};

#endif
