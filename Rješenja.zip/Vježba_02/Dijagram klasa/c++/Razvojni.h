#include <string>
using namespace std;

#ifndef __Razvojni_h__
#define __Razvojni_h__

#include "Posao.h"

// class Posao;
class Razvojni;

class Razvojni: public Posao
{
	public: string _matBrojPoduze�a;
};

#endif
