
#ifndef __Radnik_h__
#define __Radnik_h__

// #include "Pododjel.h"
#include "Zaposlenik.h"

class Pododjel;
// class Zaposlenik;
class Radnik;

class Radnik: public Zaposlenik
{
	public: Pododjel* _unnamed_Pododjel_;
};

#endif
