#include <exception>
using namespace std;

#ifndef __DirektorOdjela_h__
#define __DirektorOdjela_h__

#include "Direktor.h"

// class Direktor;
class DirektorOdjela;

class DirektorOdjela: public Direktor
{

	public: void zaposliDPO();

	public: void otpustiDPO();

	public: void otpustiRadnika();

	public: void zaposliRadnika();
};

#endif
