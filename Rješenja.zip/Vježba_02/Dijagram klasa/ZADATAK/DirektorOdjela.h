class DirektorOdjela : Direktor {


public:
	void zaposliDPO();

	void otpustiDPO();

	void otpustiRadnika();

	void zaposliRadnika();
};
