class Zaposlenik {

private:
	string maticniBrojZaposlenika;
public:
	string ime;
	string prezime;
};
