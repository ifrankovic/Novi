class Administrativni : Posao {
};
