class Radnik : Zaposlenik {
};
