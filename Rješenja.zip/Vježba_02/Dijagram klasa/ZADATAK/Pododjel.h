class Pododjel {

private:
	string nazivOdjela;
	string adresaOdjela;
	string nazivPododjela;
};
