class Odjel {

public:
	string nazivOdjela;
	string adresaOdjela;
};
