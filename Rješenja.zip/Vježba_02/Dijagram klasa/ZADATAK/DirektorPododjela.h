class DirektorPododjela : Direktor {


public:
	boolean upitZaOtpustanje();
};
