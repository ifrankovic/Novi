#include "DirektorOdjela.h"

void DirektorOdjela::zaposliDPO() {
	// TODO - implement DirektorOdjela::zaposliDPO
	throw "Not yet implemented";
}

void DirektorOdjela::otpustiDPO() {
	// TODO - implement DirektorOdjela::otpustiDPO
	throw "Not yet implemented";
}

void DirektorOdjela::otpustiRadnika() {
	// TODO - implement DirektorOdjela::otpustiRadnika
	throw "Not yet implemented";
}

void DirektorOdjela::zaposliRadnika() {
	// TODO - implement DirektorOdjela::zaposliRadnika
	throw "Not yet implemented";
}
