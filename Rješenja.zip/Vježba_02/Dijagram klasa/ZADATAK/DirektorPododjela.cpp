#include "DirektorPododjela.h"

boolean DirektorPododjela::upitZaOtpustanje() {
	// TODO - implement DirektorPododjela::upitZaOtpustanje
	throw "Not yet implemented";
}
