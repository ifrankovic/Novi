class Direktor : Zaposlenik {
};
