class Posao {

public:
	string naziv;
	date rokDovrsenja;
};
