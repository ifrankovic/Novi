#ifndef Student_h
#define Student_h

#include "integer.h"


class Student {

 public:
    integer ID;
    String ime;
};

#endif // Student_h
