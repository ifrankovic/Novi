#ifndef OdjProdaje_h
#define OdjProdaje_h

#include <vector>

#include "OrgJedinica.h"

class Sef;
class RadnikProdaje;
class Polica;

class OdjProdaje : virtual public OrgJedinica {

 public:

    virtual void izracunajCijenu();

 public:



    Sef *mySef;

    /**
     * @element-type RadnikProdaje
     */
    std::vector< RadnikProdaje* > myRadnikProdaje;

    /**
     * @element-type Polica
     */
    std::vector< Polica* > myPolica;

    /**
     * @element-type Polica
     */
    std::vector< Polica* > myPolica;
};

#endif // OdjProdaje_h
