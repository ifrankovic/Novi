#ifndef Kupci_h
#define Kupci_h

class Knjizara;
class RadnikProdaje;
class Knjiga;

class Kupci {

 public:

    virtual void konzultirajSe();

    virtual void kupiKnjigu();

 public:

    /**
     * @element-type Knjizara
     */
    Knjizara *myKnjizara;

    RadnikProdaje *myRadnikProdaje;

    /**
     * @element-type Knjiga
     */
    Knjiga *myKnjiga;
};

#endif // Kupci_h
