#ifndef Sef_h
#define Sef_h

#include "Zaposlenik.h"

class OdjProdaje;
class OdjNabave;

class Sef : public Zaposlenik {

 public:

    virtual void vodiJedinicu();

 public:

    OdjProdaje *myOdjProdaje;

    OdjNabave *myOdjNabave;
};

#endif // Sef_h
