#ifndef OdjNabave_h
#define OdjNabave_h

#include <vector>

#include "OrgJedinica.h"

class Sef;
class RadnikNabave;
class Knjiga;

class OdjNabave : virtual public OrgJedinica, virtual public OrgJedinica {

 public:

    virtual void izracunajCijenu();

 public:
    Integer newAttr;

 public:


    Sef *mySef;

    /**
     * @element-type RadnikNabave
     */
    std::vector< RadnikNabave* > myRadnikNabave;

    /**
     * @element-type Knjiga
     */
    std::vector< Knjiga* > myKnjiga;
};

#endif // OdjNabave_h
