#ifndef Polica_h
#define Polica_h

#include <vector>


class OdjProdaje;
class Knjiga;

class Polica {

 public:

    OdjProdaje *myOdjProdaje;

    /**
     * @element-type Knjiga
     */
    std::vector< Knjiga* > myKnjiga;

    OdjProdaje *myOdjProdaje;
};

#endif // Polica_h
