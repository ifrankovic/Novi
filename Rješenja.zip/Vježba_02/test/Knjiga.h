#ifndef Knjiga_h
#define Knjiga_h

class OdjNabave;
class Polica;
class Kupci;

class Knjiga {

 public:
    String ISBN;
    String naziv;

 public:

    OdjNabave *myOdjNabave;

    Polica *myPolica;

    /**
     * @element-type Kupci
     */
    Kupci *myKupci;
};

#endif // Knjiga_h
