#ifndef Zaposlenik_h
#define Zaposlenik_h


class Zaposlenik {

 public:

    virtual void izracunajPlacu();

 public:
    String Ime;
    String prezime;

 private:
    Integer OIB;
};

#endif // Zaposlenik_h
