#ifndef Knjizara_h
#define Knjizara_h

#include "OdjNabave.h"
#include "OdjProdaje.h"

class Kupci;

class Knjizara {

 public:

    /**
     * @element-type OdjNabave
     */
    OdjNabave myOdjNabave;

    /**
     * @element-type OdjProdaje
     */
    OdjProdaje myOdjProdaje;

    /**
     * @element-type OdjProdaje
     */
    OdjProdaje myOdjProdaje;

    /**
     * @element-type Kupci
     */
    Kupci *myKupci;
};

#endif // Knjizara_h
