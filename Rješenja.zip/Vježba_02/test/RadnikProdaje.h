#ifndef RadnikProdaje_h
#define RadnikProdaje_h

#include <vector>

#include "Radnik.h"

class OdjProdaje;
class Kupci;

class RadnikProdaje : public Radnik {

 public:

    OdjProdaje *myOdjProdaje;

    /**
     * @element-type Kupci
     */
    std::vector< Kupci* > myKupci;
};

#endif // RadnikProdaje_h
