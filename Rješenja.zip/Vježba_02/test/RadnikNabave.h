#ifndef RadnikNabave_h
#define RadnikNabave_h

#include "Radnik.h"

class OdjNabave;

class RadnikNabave : public Radnik {

 public:

    OdjNabave *myOdjNabave;
};

#endif // RadnikNabave_h
